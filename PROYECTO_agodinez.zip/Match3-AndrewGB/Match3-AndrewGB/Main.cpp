#include "Game.h"

int main() {
    Game app;
    app.init();
}

//Code by ANDREW GODINEZ BARAHONA
